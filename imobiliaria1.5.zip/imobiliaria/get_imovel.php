<?php
require 'config.php';

$id = $_GET['id'];
$query = $pdo->prepare("SELECT * FROM imoveis WHERE id = :id");
$query->bindParam(':id', $id);
$query->execute();
$imovel = $query->fetch(PDO::FETCH_ASSOC);

echo json_encode($imovel);
?>

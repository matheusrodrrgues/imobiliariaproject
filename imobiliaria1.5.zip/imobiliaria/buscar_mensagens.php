<?php
require 'config.php';

session_start();

if (!isset($_SESSION['user_id']) || !isset($_GET['destinatario_id'])) {
    die('Usuário não autenticado ou ID do destinatário não especificado.');
}

$user_id = $_SESSION['user_id'];
$destinatario_id = $_GET['destinatario_id'];

// Buscar mensagens entre o usuário e o destinatário
$query = $pdo->prepare("SELECT * FROM mensagens WHERE (remetente_id = :user_id AND destinatario_id = :destinatario_id) OR (remetente_id = :destinatario_id AND destinatario_id = :user_id) ORDER BY data_envio ASC");
$query->bindParam(':user_id', $user_id);
$query->bindParam(':destinatario_id', $destinatario_id);
$query->execute();

$mensagens = $query->fetchAll(PDO::FETCH_ASSOC);

// Retornar mensagens em formato JSON
echo json_encode($mensagens);
?>
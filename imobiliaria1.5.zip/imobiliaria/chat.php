<?php
session_start();
require 'config.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$destinatario_id = $_GET['destinatario_id']; // ID do destinatário (corretor) passado pela URL

// Processar o envio de mensagem
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['mensagem'])) {
    $mensagem = $_POST['mensagem'];

    // Inserir a nova mensagem na tabela de mensagens
    $query = $pdo->prepare("INSERT INTO mensagens (remetente_id, destinatario_id, mensagem) VALUES (:remetente_id, :destinatario_id, :mensagem)");
    $query->bindParam(':remetente_id', $user_id);
    $query->bindParam(':destinatario_id', $destinatario_id);
    $query->bindParam(':mensagem', $mensagem);
    $query->execute();

    // Obter o ID do imóvel relacionado à mensagem
    $imovel_id = $_GET['imovel_id'];  // Supondo que o imóvel esteja sendo passado como parâmetro na URL

    // Inserir notificação para o corretor
    $notificacao_query = $pdo->prepare("INSERT INTO notificacoes (corretor_id, imovel_id, mensagem) VALUES (:corretor_id, :imovel_id, :mensagem)");
    $notificacao_query->bindParam(':corretor_id', $destinatario_id);
    $notificacao_query->bindParam(':imovel_id', $imovel_id);
    $notificacao_query->bindParam(':mensagem', $mensagem);
    $notificacao_query->execute();

    // Enviar resposta JSON
    echo json_encode(['status' => 'sucesso']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat com Corretor</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.1.2/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 text-gray-800">

<div class="max-w-lg mx-auto mt-8 p-6 bg-white shadow-md rounded-lg">
    <h2 class="text-2xl font-semibold mb-4">Conversar com Corretor</h2>

    <!-- Exibir mensagens -->
    <div id="mensagens" class="mb-4 max-h-96 overflow-y-auto">
        <!-- As mensagens serão inseridas aqui via JavaScript -->
        <?php foreach ($mensagens as $mensagem): ?>
            <div class="<?= $mensagem['remetente_id'] == $user_id ? 'text-right' : 'text-left' ?>">
                <p class="font-semibold"><?= $mensagem['remetente_id'] == $user_id ? 'Você' : 'Corretor' ?>:</p>
                <p class="bg-gray-200 inline-block p-2 rounded-lg"><?= htmlspecialchars($mensagem['mensagem']) ?></p>
                <p class="text-sm text-gray-500"><?= (new DateTime($mensagem['data_envio']))->format('d/m/Y H:i') ?></p>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Formulário para enviar mensagem -->
    <form method="POST" action="">
        <div class="mb-4">
            <textarea name="mensagem" id="mensagem" class="w-full px-4 py-2 border border-gray-300 rounded" placeholder="Digite sua mensagem" required></textarea>
        </div>
        <button type="button" id="enviar" class="bg-blue-500 text-white px-4 py-2 rounded w-full">Enviar</button>
    </form>
</div>

<script>
    var destinatarioId = <?php echo $_GET['destinatario_id']; ?>; // ID do destinatário passado pela URL
    var userId = <?php echo $_SESSION['user_id']; ?>; // ID do usuário logado

    // Função para carregar as mensagens
    function carregarMensagens() {
        fetch('buscar_mensagens.php?destinatario_id=' + destinatarioId)
            .then(response => response.json())
            .then(mensagens => {
                const mensagensDiv = document.getElementById('mensagens');
                mensagensDiv.innerHTML = ''; // Limpar mensagens antigas

                mensagens.forEach(mensagem => {
                    const div = document.createElement('div');
                    div.classList.add(mensagem.remetente_id == userId ? 'text-right' : 'text-left');
                    div.innerHTML = `
                        <p class="font-semibold">${mensagem.remetente_id == userId ? 'Você' : 'Corretor'}:</p>
                        <p class="bg-gray-200 inline-block p-2 rounded-lg">${mensagem.mensagem}</p>
                        <p class="text-sm text-gray-500">${new Date(mensagem.data_envio).toLocaleString()}</p>
                    `;
                    mensagensDiv.appendChild(div);
                });

                // Scroll para a última mensagem
                mensagensDiv.scrollTop = mensagensDiv.scrollHeight;
            });
    }

    // Carregar as mensagens ao abrir a página
    carregarMensagens();

    // Atualizar as mensagens a cada 3 segundos
    setInterval(carregarMensagens, 3000);

    // Enviar nova mensagem
    document.getElementById('enviar').addEventListener('click', function() {
        var mensagem = document.getElementById('mensagem').value;

        if (mensagem.trim() === '') return; // Não enviar mensagem vazia

        // Enviar a nova mensagem via AJAX
        fetch('chat.php?destinatario_id=' + destinatarioId, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'mensagem=' + encodeURIComponent(mensagem)
        }).then(response => response.json())
          .then(data => {
              document.getElementById('mensagem').value = ''; // Limpar campo de mensagem
              carregarMensagens(); // Recarregar as mensagens após enviar
          });
    });
</script>

</body>
</html>

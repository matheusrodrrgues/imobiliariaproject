
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault(); 

    // Dados de exemplo para autenticação
    const validUser = {
        email: "admin@matheus.com",
        password: "123456"
    };

    // Dados inseridos no formulário
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Validação
    if (email === validUser.email && password === validUser.password) {
        window.location.href = "profile.html";
    } else {
    // Exibe mensagem de erro
        const errorMessage = document.getElementById("error-message");
        errorMessage.classList.remove("hidden");
        errorMessage.textContent = "Credenciais inválidas. Tente novamente.";
    }
    // Simulação após login bem-sucedido (coloque no auth.js)
    localStorage.setItem("user", JSON.stringify({
    name: "Matheus Silva",
    email: "matheus@admin.com",
    avatar: "images/perfil.webp"  // caminho para a foto de perfil
}));

});

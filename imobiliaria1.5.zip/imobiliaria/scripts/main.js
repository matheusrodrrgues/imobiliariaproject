// auth.js
document.getElementById('loginForm').addEventListener('submit', (event) => {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    // Autenticação simulada (substitua por lógica real)
    if (email === 'usuario@teste.com' && password === '123456') {
        alert('Login bem-sucedido');
        window.location.href = 'profile.html'; // Redireciona para o perfil
    } else {
        alert('Credenciais inválidas');
    }
});

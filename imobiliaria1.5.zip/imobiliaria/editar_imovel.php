<?php
session_start();
require 'config.php';

$id = $_POST['id'];
$foto = $_POST['foto'];
$titulo = $_POST['titulo'];
$descricao = $_POST['descricao'];
$valor = $_POST['valor'];

$query = $pdo->prepare("UPDATE imoveis SET foto_url = :foto, titulo = :titulo, descricao = :descricao, valor = :valor WHERE id = :id");
$query->bindParam(':foto', $foto);
$query->bindParam(':titulo', $titulo);
$query->bindParam(':descricao', $descricao);
$query->bindParam(':valor', $valor);
$query->bindParam(':id', $id);
$query->execute();

header("Location: dashboard.php");
exit();
?>

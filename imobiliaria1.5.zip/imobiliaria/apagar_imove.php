<?php
session_start();
require 'config.php';

$id = $_POST['id'];
$query = $pdo->prepare("DELETE FROM imoveis WHERE id = :id");
$query->bindParam(':id', $id);
$query->execute();

header("Location: dashboard.php");
exit();
?>

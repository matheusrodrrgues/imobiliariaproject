// Função para carregar informações do usuário
function loadUserProfile() {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) {
        alert("Você precisa estar logado para acessar o perfil.");
        window.location.href = "login.html";
        return;
    }

    document.getElementById("user-name").textContent = user.name || "Usuário Anônimo";
    document.getElementById("user-email").textContent = user.email || "Email não disponível";
    document.getElementById("user-avatar").src = user.avatar || "assets/images/avatar-placeholder.png";
}

// Função para salvar configurações do perfil
document.getElementById("save-settings").addEventListener("click", (e) => {
    e.preventDefault();

    const updatedUser = {
        name: document.getElementById("full-name").value,
        email: document.getElementById("email").value,
        avatar: document.getElementById("avatar-url").value
    };

    localStorage.setItem("user", JSON.stringify(updatedUser));
    alert("Configurações salvas com sucesso!");
    loadUserProfile(); // Atualiza o perfil na página

    // Fechar o modal
    document.getElementById("settings-modal").classList.add("hidden");
});

// Função de logout
document.getElementById("logout-button").addEventListener("click", () => {
    localStorage.removeItem("user");
    window.location.href = "login.html";
});

// Exibir o modal de configurações
document.getElementById("settings-button").addEventListener("click", () => {
    document.getElementById("settings-modal").classList.remove("hidden");
});

// Fechar o modal sem salvar
document.getElementById("close-settings").addEventListener("click", () => {
    document.getElementById("settings-modal").classList.add("hidden");
});

// Função do dropdown no menu lateral
document.querySelectorAll('.dropdown').forEach(dropdown => {
    dropdown.addEventListener('click', () => {
        const menu = dropdown.nextElementSibling;
        menu.classList.toggle('hidden');
    });
});

// Configuração do gráfico com Chart.js
function loadChart() {
    const ctx = document.getElementById('myChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio'],
            datasets: [{
                label: 'Atividades',
                data: [12, 19, 3, 5, 2],
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
}

// Configuração da tabela com Tabulator.js
function loadTable() {
    const tableData = [
        {id:1, name:"Alice", age:25, gender:"F"},
        {id:2, name:"Bob", age:30, gender:"M"},
        {id:3, name:"Charlie", age:35, gender:"M"},
    ];

    new Tabulator("#table", {
        data: tableData,
        layout: "fitColumns",
        columns: [
            {title:"ID", field:"id", width:50},
            {title:"Nome", field:"name", editor:"input"},
            {title:"Idade", field:"age", editor:"input"},
            {title:"Gênero", field:"gender", editor:"select", editorParams:{values:["M", "F"]}}
        ]
    });
}

// Inicializar a página e carregar todos os dados necessários
document.addEventListener("DOMContentLoaded", () => {
    loadUserProfile();
    loadChart();
    loadTable();
});

<!DOCTYPE html>
<html lang="pt-br">

<?php
// Conexão com o banco de dados
$host = 'localhost';
$db = 'imobiliaria';  
$user = 'root';        
$pass = 'admin';            

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $pdo->query('SELECT * FROM imoveis1');
    $imoveis = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Erro na conexão com o banco de dados: " . $e->getMessage();
    $imoveis = [];
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imobiliária Barreto | Seus imóveis em um só lugar</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Estilos principais */
        body {
            font-family: 'Poppins', sans-serif;
            color: #333;
            margin: 0;
            background-color: #f4f4f4;
        }

        /* Navbar */
        .navbar {
            background: transparent;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 10;
            padding: 15px;
        }

        .navbar-brand,
        .navbar-nav .nav-link {
            color: #fff !important;
            font-weight: 600;
        }

        /* Hero */
        .hero {
            height: 500px;
            background: 
                linear-gradient(
                    rgba(0, 0, 0, 0.5), /* Sombra escura */
                    rgba(0, 0, 0, 0.5)
                ), 
                url(https://p.w3layouts.com/demos_new/template_demo/01-02-2021/estates-liberty-demo_Free/729679730/web/assets/images/banner.jpg) no-repeat center center;
            background-size: cover;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            flex-direction: column;
            position: relative;
            clip-path: polygon(0 0, 100% 0, 100% 90%, 50% 100%, 0 90%);
        }

        .hero h1 {
            font-size: 3.5rem;
            font-weight: 700;
        }

        .hero p {
            font-size: 1.5rem;
            margin-top: 15px;
        }

        .hero .btn-primary {
            background-color: #f1c40f;
            border-color: #f1c40f;
            padding: 12px 25px;
            font-size: 1.2rem;
            font-weight: bold;
            border-radius: 30px;
        }

        /* Services Section */
        .services {
            padding: 60px 0;
            background-color: #fff;
        }

        .services h2 {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2c3e50;
            text-align: center;
            margin-bottom: 40px;
        }

        .service-item {
            text-align: center;
            padding: 20px;
            border-radius: 8px;
            transition: transform 0.3s ease;
        }

        .service-item:hover {
            transform: scale(1.05);
        }

        .service-icon {
            font-size: 2.5rem;
            color: #f1c40f;
            margin-bottom: 20px;
        }

        .service-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #2c3e50;
        }

        .service-description {
            font-size: 1rem;
            color: #7f8c8d;
        }

        /* Stats Section */
        .stats {
            padding: 60px 0;
            background-color: #2C3E50;
            color: #fff;
            text-align: center;
        }

        .stats .stat-item {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .stats .stat-item .number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #f1c40f;
            display: block;
        }
          /* Properties Section */
          .properties {
            padding: 80px 0;
            background-color: #fff;
        }
        .property-card {
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.property-card img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

.card-body {
    padding: 15px;
}

.price {
    font-size: 1.2rem;
    font-weight: bold;
    color: #e67e22;
}
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Imobiliária Barreto</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="#home">Início</a></li>
                    <li class="nav-item"><a class="nav-link" href="#about">Sobre</a></li>
                    <li class="nav-item"><a class="nav-link" href="#services">Serviços</a></li>
                    <li class="nav-item"><a class="nav-link" href="#imoveis">Imóveis</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact">Contato</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <h1>Imobiliária Barreto</h1>
        <p>A busca pelo imóvel do seu sonhos termina aqui!</p>
        <a href="#imoveis" class="btn-primary">Veja os imóveis</a>
    </section>

    <!-- Services Section -->
    <section id="services" class="services">
        <div class="container">
            <h2 class="text-center mb-5">Serviços</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="service-item">
                        <div class="service-icon"><i class="fas fa-home"></i></div>
                        <h4 class="service-title">Consultoria Imobiliária</h4>
                        <p class="service-description">Ajudamos você a encontrar o imóvel ideal de acordo com suas necessidades e orçamento.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-item">
                        <div class="service-icon"><i class="fas fa-key"></i></div>
                        <h4 class="service-title">Gestão de Locação</h4>
                        <p class="service-description">Oferecemos um serviço completo de gestão de locação para sua maior comodidade e segurança.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-item">
                        <div class="service-icon"><i class="fas fa-handshake"></i></div>
                        <h4 class="service-title">Compra e Venda</h4>
                        <p class="service-description">Facilitamos o processo de compra e venda de imóveis, proporcionando uma experiência tranquila e segura.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-item">
                        <span class="number">0+</span>
                        Total de Imóveis
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-item">
                        <span class="number">0+</span>
                        Imóveis vendidos
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-item">
                        <span class="number">0+</span>
                        Clientes satisfeitos
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-item">
                        <span class="number">0+</span>
                        Total de Corretores
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Properties Section -->
    <!-- Properties Section -->
<section id="imoveis" class="properties">
    <div class="container">
        <h2 class="text-center mb-5">Imóveis Recentes</h2>
        <div class="row">
            <?php if (!empty($imoveis)): ?>
                <?php foreach ($imoveis as $imovel): ?>
                    <div class="col-md-4 mb-4">
                        <div class="property-card">
                            <img src="<?php echo $imovel['imagem']; ?>" alt="<?php echo htmlspecialchars($imovel['titulo']); ?>" class="img-fluid" style="height: 250px; object-fit: cover;">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($imovel['titulo']); ?></h5>
                                <p class="price">R$ <?php echo number_format($imovel['valor'], 2, ',', '.'); ?></p>
                                <p class="card-text"><?php echo htmlspecialchars($imovel['descricao']); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center">Nenhum imóvel encontrado.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Footer Section -->
<footer class="footer py-5" style="background-color: #2C3E50; color: #f9f9f9;">
    <div class="container">
        <div class="row">
            <!-- About Section -->
            <div class="col-md-4 mb-4">
                <h5>Sobre Nós</h5>
                <p style="font-size: 0.9rem;">
                    Somos uma empresa dedicada a ajudar você a encontrar o imóvel perfeito. Nosso compromisso é fornecer um serviço confiável e transparente para todos os nossos clientes.
                </p>
                <p><strong>Telefone:</strong> +55 21 1234-5678</p>
                <p><strong>Email:</strong> contato@imobiliariabarreto.com</p>
            </div>

            <!-- Quick Links Section -->
            <div class="col-md-4 mb-4">
                <h5>Links Rápidos</h5>
                <ul class="list-unstyled">
                    <li><a href="#home" class="text-white" style="text-decoration: none;">Início</a></li>
                    <li><a href="#services" class="text-white" style="text-decoration: none;">Serviços</a></li>
                    <li><a href="#imoveis" class="text-white" style="text-decoration: none;">Imóveis</a></li>
                    <li><a href="#contact" class="text-white" style="text-decoration: none;">Contato</a></li>
                    <li><a href="#about" class="text-white" style="text-decoration: none;">Sobre</a></li>
                </ul>
            </div>

            <!-- Newsletter Section -->
            <div class="col-md-4 mb-4">
                <h5>Assine nossa Newsletter</h5>
                <p style="font-size: 0.9rem;">
                    Receba atualizações e novidades diretamente no seu email.
                </p>
                <form action="#" method="post">
                    <div class="input-group">
                        <input type="email" class="form-control" placeholder="Seu email" required>
                        <div class="input-group-append">
                            <button class="btn btn-primary" style="background-color: #f1c40f; border-color: #f1c40f;" type="submit">Assinar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <hr style="border-top: 1px solid #f1c40f;">

        <div class="row">
            <div class="col-md-6">
                <p class="mb-0" style="font-size: 0.8rem;">&copy; 2024 Imobiliária Barreto. Todos os direitos reservados.</p>
            </div>
            <div class="col-md-6 text-right">
                <ul class="list-inline mb-0">
                    <li class="list-inline-item"><a href="#" class="text-white" style="text-decoration: none;"><i class="fab fa-facebook-f"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="text-white" style="text-decoration: none;"><i class="fab fa-twitter"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="text-white" style="text-decoration: none;"><i class="fab fa-instagram"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="text-white" style="text-decoration: none;"><i class="fab fa-linkedin-in"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

document.addEventListener('DOMContentLoaded', () => {
    const openCadastroModalBtn = document.getElementById('open-cadastro-modal');
    const cadastroModal = document.getElementById('cadastro-modal');
    const closeModalBtn = document.getElementById('close-modal');
    const imovelForm = document.getElementById('imovel-form');
    const imoveisList = document.getElementById('imoveis-list');

    // Abrir o modal
    openCadastroModalBtn.addEventListener('click', () => {
        cadastroModal.classList.remove('hidden');
    });

    // Fechar o modal
    closeModalBtn.addEventListener('click', () => {
        cadastroModal.classList.add('hidden');
    });

    // Enviar o formulário e cadastrar o imóvel
    imovelForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const foto = document.getElementById('foto').value;
        const descricao = document.getElementById('descricao').value;
        const valor = document.getElementById('valor').value;

        const imovelDiv = document.createElement('div');
        imovelDiv.classList.add('project', 'bg-white', 'p-6', 'shadow-md', 'rounded-lg');

        imovelDiv.innerHTML = `
            <img src="${foto}" alt="Foto do Imóvel" class="w-full h-48 object-cover rounded-lg mb-4">
            <h3 class="text-xl font-semibold">Descrição:</h3>
            <p class="text-gray-600">${descricao}</p>
            <p class="text-gray-800 font-semibold mt-2">Valor: R$ ${valor}</p>
        `;

        imoveisList.appendChild(imovelDiv);

        // Fechar o modal após o cadastro
        cadastroModal.classList.add('hidden');

        // Limpar o formulário
        imovelForm.reset();
    });
});

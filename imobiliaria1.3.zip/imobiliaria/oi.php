<?php
session_start();
require 'config.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Obter dados do usuário
$query = $pdo->prepare("SELECT * FROM usuarios WHERE id = :id");
$query->bindParam(':id', $user_id);
$query->execute();
$user = $query->fetch();

// Buscar notificações para o corretor
$query_notificacoes = $pdo->prepare("SELECT * FROM notificacoes WHERE corretor_id = :corretor_id AND lida = 0");
$query_notificacoes->bindParam(':corretor_id', $user_id);
$query_notificacoes->execute();
$notificacoes = $query_notificacoes->fetchAll();

// Cadastro de imóvel
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $foto = $_POST['foto'];
    $titulo = $_POST['titulo'];
    $descricao = $_POST['descricao'];
    $valor = $_POST['valor'];

    $query = $pdo->prepare("INSERT INTO imoveis (foto_url, descricao, titulo, valor, usuario_id) VALUES (:foto, :descricao, :titulo, :valor, :usuario_id)");
    $query->bindParam(':foto', $foto);
    $query->bindParam(':descricao', $descricao);
    $query->bindParam(':titulo', $titulo);
    $query->bindParam(':valor', $valor);
    $query->bindParam(':usuario_id', $user_id);
    $query->execute();
}

// Correção:
$query_imoveis = $pdo->prepare("SELECT * FROM imoveis WHERE usuario_id = :usuario_id");
$query_imoveis->bindParam(':usuario_id', $user_id);
$query_imoveis->execute();
$imoveis = $query_imoveis->fetchAll();
// Coletar valores para o gráfico
$valores_imoveis = [];
$titulos_imoveis = [];
foreach ($imoveis as $imovel) {
    $valores_imoveis[] = $imovel['valor'];
    $titulos_imoveis[] = $imovel['titulo'];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imobiliária Barreto | Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.1.2/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<style>
    #notificacoes ul li {
        background-color: #f3f4f6;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    #notificacoes a {
        color: #1D4ED8;
        text-decoration: none;
    }

    #notificacoes a:hover {
        text-decoration: underline;
    }

    /* Estilo para o cabeçalho e o menu */
    .header-menu {
        background-color: #1D4ED8;
        padding: 10px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .header-menu .logo {
        font-size: 1.5rem;
        font-weight: bold;
        color: white;
    }

    .header-menu .nav-links {
        display: flex;
        justify-content: flex-end;
    }

    .header-menu .nav-links a {
        color: white;
        padding: 10px;
        text-decoration: none;
        margin: 0 10px;
        font-size: 1.1rem;
    }

    .header-menu .nav-links a:hover {
        background-color: #2563eb;
        border-radius: 5px;
    }

    .sub-header {
        background-color: #f3f4f6;
        padding: 10px 20px;
        font-size: 1.3rem;
        font-weight: bold;
    }

    /* Ajustar o container principal */
    .main-container {
        max-width: 1200px;  /* Largura máxima para centralizar */
        margin: 0 auto;    /* Centraliza o conteúdo horizontalmente */
        padding: 20px;     /* Espaçamento interno */
        display: flex;
        gap: 20px;
    }

    /* Box de Menu à direita com recuo */
    .right-sidebar {
        width: 300px;
        background-color: #ffffff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        margin-left: 40px; /* Recuo do menu */
    }

    .right-sidebar a {
        display: block;
        padding: 10px;
        margin: 10px 0;
        text-decoration: none;
        color: #1D4ED8;
        font-size: 1.1rem;
    }

    .right-sidebar a:hover {
        background-color: #f3f4f6;
        border-radius: 5px;
    }
</style>
<body class="bg-gray-100 text-gray-800 font-sans">

    <div class="flex min-h-screen flex-col">
        
        <!-- Menu Superior -->
        <div class="header-menu">
            <!-- Logo à esquerda -->
            <div class="logo">
                IMOBILIÁRIA BARRETO
            </div>
            <!-- Opções de Navegação à direita -->
            <div class="nav-links">
                <a href="index.php">Início</a>
                <a href="meus_imoveis.php">Meus Imóveis</a>
                <a href="analises.php">Análises</a>
                <a href="perfil.php">Perfil</a>
                <a href="logout.php" class="bg-red-500 text-white px-4 py-2 rounded-lg">Sair</a>
            </div>
        </div>

        <!-- Cabeçalho Secundário -->
        <div class="sub-header">
            Painel de Controle
        </div>

        <!-- Área Principal -->
        <main class="main-container">
            <!-- Conteúdo principal à esquerda -->
            <div class="flex-1">
                <!-- Notificações -->
                <section id="notificacoes">
                    <h3 class="text-xl font-semibold mb-4">Notificações</h3>
                    <ul>
                        <?php foreach ($notificacoes as $notificacao): ?>
                            <li>
                                <a href="imovel.php?id=<?= $notificacao['imovel_id']; ?>" onclick="markAsRead(<?= $notificacao['imovel_id']; ?>)">
                                    <?= htmlspecialchars($notificacao['mensagem']); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </section>

                <!-- Gráfico de Valores dos Imóveis -->
                <section class="mt-8">
                    <h3 class="text-xl font-semibold mb-4">Gráfico de Valores dos Imóveis</h3>
                    <canvas id="graficoValores" width="400" height="200"></canvas>
                    <script>
                        var ctx = document.getElementById('graficoValores').getContext('2d');
                        var graficoValores = new Chart(ctx, {
                            type: 'bar',
                            data: {
                                labels: <?php echo json_encode($titulos_imoveis); ?>,
                                datasets: [{
                                    label: 'Valor dos Imóveis',
                                    data: <?php echo json_encode($valores_imoveis); ?>,
                                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                    borderColor: 'rgba(75, 192, 192, 1)',
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                scales: {
                                    y: {
                                        beginAtZero: true
                                    }
                                }
                            }
                        });
                    </script>
                </section>

                <!-- Tabela de Imóveis -->
                <section class="mt-8">
                    <h3 class="text-xl font-semibold mb-4">Tabela de Imóveis</h3>
                    <table class="min-w-full bg-white border border-gray-300 rounded-lg shadow-lg">
                        <thead>
                            <tr>
                                <th class="px-4 py-2 border-b">Título</th>
                                <th class="px-4 py-2 border-b">Descrição</th>
                                <th class="px-4 py-2 border-b">Valor</th>
                                <th class="px-4 py-2 border-b">Foto</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($imoveis as $imovel): ?>
                                <tr>
                                    <td class="px-4 py-2 border-b"><?= htmlspecialchars($imovel['titulo']); ?></td>
                                    <td class="px-4 py-2 border-b"><?= htmlspecialchars($imovel['descricao']); ?></td>
                                    <td class="px-4 py-2 border-b">R$ <?= number_format($imovel['valor'], 2, ',', '.'); ?></td>
                                    <td class="px-4 py-2 border-b"><img src="<?= htmlspecialchars($imovel['foto_url']); ?>" alt="<?= htmlspecialchars($imovel['titulo']); ?>" class="w-24 h-24 object-cover"></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </section>
            </div>

            <!-- Menu à Direita -->
            <div class="right-sidebar">
                <h3 class="font-semibold text-lg mb-4">Opções</h3>
                <a href="novo_imovel.php">Cadastrar Novo Imóvel</a>
                <a href="analises.php">Análises de Imóveis</a>
                <a href="perfil.php">Configurações do Perfil</a>
            </div>
        </main>
    </div>
</body>
</html>
